import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lower-bar',
  templateUrl: './lower-bar.component.html',
  styleUrls: ['./lower-bar.component.css']
})
export class LowerBarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
