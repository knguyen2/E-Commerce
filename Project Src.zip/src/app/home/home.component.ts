import { Component, OnInit } from '@angular/core';
/*
import { Product } from './../shared/product';
import { ProductService } from '../services/product.service';
import { PRODUCTItems } from './../shared/PRODUCTItems';
import { ProductdetailComponent } from './../productdetail/productdetail.component';

const PRODUCTItems: Product[] = [
  {
    name:'Green Blouse',
    image:'/assets/images/GreenBlouse.jpg',
    category:'Shirts',
    label:'New In',
    price:'$$',
    description:'Green color blouse'
  },

  {
    name:'Black Blouse',
    image:'/assets/images/BlackBlouse.jpg',
    category:'Shirts',
    label:'New In',
    price:'$$',
    description:'Black color blouse'
  },

  {
    name:'Patern Belt',
    image:'./assets/images/Belt.jpg',
    category:'Accessories',
    label:'New In',
    price:'$',
    description:'Patern waist belt'
  },

  {
    name:'Statement Neckless',
    image:'./assets/images/StatementNeckless.jpg',
    category:'Accessories',
    label:'On Sale',
    price:'$',
    description:'Trendy Silver Statement Neckless'
  },

  {
    name:'Swing Dress',
    image:'./assets/images/SwingDress.jpg',
    category:'Dresses',
    label:'New IN',
    price:'$$',
    description:'Butterfly dress'
  },

  {
    name:'Red Pants',
    image:'./assets/images/RedPants.jpg',
    category:'Pants',
    label:'New IN',
    price:'$$',
    description:'Red Pants'
  },
];
*/

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})

export class HomeComponent implements OnInit {

/*products = PRODUCTItems;

  type: Product;

  selectedProduct = this.products[0];

  products: Product[];
  type: Product;

  onSelect(product:Product){
    this.type = product;

 
  }
*/

  constructor() { }

  ngOnInit() {

  }

}  
