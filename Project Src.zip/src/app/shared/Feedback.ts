
export class Feedback {
    rating: number;
    comment: string;
    author: string;
    date: string;
}